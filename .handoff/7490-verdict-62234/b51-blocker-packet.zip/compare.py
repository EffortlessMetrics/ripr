import pathlib,subprocess,json,hashlib,collections
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-b51')
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def files(rev,prefix):return subprocess.check_output(['git','ls-tree','-r','--name-only',rev,prefix],cwd=root,text=True).splitlines()
def read(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=root)
def load(rev,p):return json.loads(read(rev,p))
def definitions(rev,lang):
    base=f'fixtures/{lang}-verdict-corpus/'
    corpus=load(rev,base+'corpus.json')
    subjects={s['subject_id']:s for p in files(rev,base+'subjects/') if p.endswith('.json') and len(p[len(base+'subjects/'):].split('/'))==1 for s in [load(rev,p)]}
    cases={c['case_id']:c for p in files(rev,base+'cases/') if p.endswith('.json') for c in [load(rev,p)]}
    result={}
    for cid,c in cases.items():
        s=subjects[c['subject_id']]
        identity=dict(origin=s.get('origin','upstream'),upstream=s.get('upstream'),commit=s.get('commit'),files=sorted([dict(path=f['path'],sha256=f['sha256']) for f in s['retained_files']],key=lambda x:x['path']))
        mutants=sorted([dict(replacement=m['replacement'],outcome=m['outcome']) for m in c['truth']['mutants']],key=canonical)
        definition=dict(schema=corpus['schema_version'],projection=corpus['verdict_projection'],case_id=cid,subject_id=c['subject_id'],anchor=c['anchor'],edit_kind=c['edit_kind'],truth=c['truth']['state'],ideal=c['expected']['ideal_verdict'],acceptable=sorted(c['expected']['acceptable_verdicts'],key=canonical),mutants=mutants,diff_sha256=digest(read(rev,base+c['diff'])),subject=identity)
        if c.get('perl_facts'):definition['perl_facts']=dict(sha256=c['perl_facts']['sha256'],provenance=c['perl_facts']['provenance'],producer=corpus.get('fact_producer'))
        result[cid]=dict(hash=digest(canonical(definition).encode()),definition=definition)
    return result
current='b51aebc7e4735529befd677ebf14071c7f09e477'
langs=['rust','typescript','python','perl']
defs={l:definitions(current,l) for l in langs}
(out/'definitions.json').write_text(json.dumps(defs,indent=2))
baseline=json.loads((root/'benchmarks/dx_scoreboard/testdata/7552-original-baseline-with-population.json').read_text())
def walk(v):
    if isinstance(v,dict):
        if v.get('schema_version')=='ripr-verdict-case-population-v1':yield v
        for x in v.values():yield from walk(x)
    elif isinstance(v,list):
        for x in v:yield from walk(x)
original=list(walk(baseline))
checks=[dict(rate=p['rate'],cases=len(p['cases']),mismatches=[c['case_id'] for c in p['cases'] if defs['rust'].get(c['case_id'],{}).get('hash')!=c['definition_sha256']]) for p in original]
comparisons={}
for rev in ['3855533a7e8ecdfcd075b5895aa334fc10863466','806147b2184d1ff703a883abf68215228a7d2bef','984c69a290486b1da9d91700a6f771045ab079e1']:
    old=definitions(rev,'rust'); now=defs['rust']
    common=sorted(set(old)&set(now)); unchanged=[c for c in common if old[c]['hash']==now[c]['hash']]
    comparisons[rev]=dict(unchanged=unchanged,changed=[c for c in common if c not in unchanged],added=sorted(set(now)-set(old)),removed=sorted(set(old)-set(now)))
(out/'comparison-identities.json').write_text(json.dumps(dict(original_population_validation=checks,historical_partitions=comparisons),indent=2))
print(json.dumps(dict(original_population_validation=checks,partitions={r:{k:len(v) for k,v in p.items()} for r,p in comparisons.items()}),indent=2))
