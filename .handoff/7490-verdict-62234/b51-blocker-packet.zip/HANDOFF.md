# Exact-candidate verdict packet: blocked before scoring

Owner: integration thread 01a1a959-f983-763a-96e6-7dbe1cced019. Lane: swarm #7490 only.

Verified fetched ref `successor/011-pr13325-composition-02cddbb27` at commit `b51aebc7e4735529befd677ebf14071c7f09e477`, tree `d3142dd59d4dcfea5e6b4981732f61c8516f3fa0`. Checkout restored clean to this identity after diagnostic validation.

## Exact-candidate execution

Environment: Linux x86_64, Bash, rustc 1.95.0 (59807616e 2026-04-14), cargo 1.95.0 (f2d3ce0bd 2026-03-21). Process-local PATH=/workspace/.cargo/bin:$PATH, CARGO_HOME=/workspace/.cargo, RUSTUP_HOME=/workspace/.rustup, CARGO_BUILD_JOBS=1, CARGO_INCREMENTAL=0, RAYON_NUM_THREADS=1.

`cargo build --locked -p xtask`: exit 0, dev build 5m31s. xtask SHA256 `dcc1be0a9c33c91bee3e2b9477dad210c38c1fbdfce2953e2d310464d14d3444`.

`/workspace/ripr-swarm/target/debug/xtask verdict-corpus check-all`: exit 1, 2.001s. All four corpora reject spec scopes RIPR-SPEC-0374 and RIPR-SPEC-0375 because their integrated acceptance examples are unnumbered prose. Validation occurs before corpus analyzer execution. Selected inventory: Rust 846, TS 373, Python 385, Perl 94; executed/scored analyzer cases: **0**. False outcomes, abstentions and accuracy on this candidate are **not established**, never zero. No product executable was built for measurement. Repeat and trust gate were not reached.

Corpus Git-object inventory SHA256: `ae11c9087427a304e3169e8b33739f0df4f2ca440cf68c7ce9f503d2ef4c18b7` (corpus-inventory.txt).

## Minimal owner repair

`spec-scope-repair.patch` changes only the eight spec-scope TOMLs (two specs in four languages), using existing `unmeasured = true` for prose-only examples. It retains reasons, cases, labels, expected rows and scoring definitions. SHA256 `0923e1ffc6e3b42f037a86c2d43454260ed15c1ebd700f20a365d5483b8e6e52`.

Diagnostic only: with that patch temporarily applied, existing `xtask verdict-corpus validate --language <rust|typescript|python|perl>` each exits 0. This is patched-metadata validation, not an exact-candidate analyzer result. The patch was then reverted from the checkout. No candidate commit, branch push, CI, release-selection or release mutation.

Next owner action: apply/reconcile the metadata patch, publish a new full pin/tree, then resume the guarded complete check/report/repeat/trust procedure. Do not bypass validation or call patched-tree results b51 results.

## Comparable population audit

compare.py transcribes the existing #7552 definition inputs from xtask/src/reports/dx_scoreboard/population.rs; it is an analytical identity audit, not a new classifier. Definitions and partitions are retained in definitions.json and comparison-identities.json. The 199 unchanged original-203 hashes validate exactly against the existing baseline fixture; four changed definitions are separately identified: serde-derive-rename-field-upper, serde-derive-rename-variant-lower, serde-format-u8-hundreds, serde-format-u8-tens. Do not describe the whole original 203 as unchanged.

Rust historical partitions versus selected inventory:

| Historical source | Unchanged | Changed definitions | Added | Removed |
|---|---:|---:|---:|---:|
| 3855533a7e8ecdfcd075b5895aa334fc10863466 | 448 | 29 | 369 | 0 |
| 806147b2184d1ff703a883abf68215228a7d2bef | 460 | 29 | 357 | 0 |
| 984c69a290486b1da9d91700a6f771045ab079e1 | 846 | 0 | 0 | 0 |

These are source/definition identities only. Historical expected rows are committed observations; historical executables/raw runs were not freshly replayed. The prior Windows main-tip 1698-case zero-false/503-abstention result remains its own source-bound observation.

## Remaining acceptance and holds

Need full fresh current measures and stable repeat, truth-cohort error denominators, full/comparable/origin/packet-provenance slices, missed-credit and abstention counts, per-cluster dispositions, integrity controls, and trust gate. Preserve #9430/#9619 residuals and #2766 adjudication; former false-to-limited outcomes are not repaired discrimination. #11394/#11244 remain explicit disposition inputs. This packet does not accept their release status.

All five release-selection rows stay pending, hard-cut inactive, public #1893 and draft #1889 trust holds unchanged. Source attribution and public-promotion boundaries remain intact.

Resources: one build and one bounded check driver terminated normally. No lane-owned cargo/rustc remains. Build state retained for this lane's continuation; logs, comparison inputs and repair patch retained for owner consumption. No cleanup of unrelated or seeded state. Observed generation stayed within 12 GiB growth, 4 GiB disk reserve and 2 GiB cgroup-memory reserve; check driver enforced these limits and a 1800s command timeout. Full-library suite was not run.
