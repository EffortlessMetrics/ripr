import os, pathlib, subprocess, time, json, shutil, signal
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-62234')
env=dict(os.environ,PATH='/workspace/.cargo/bin:'+os.environ['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='1')
start_free=shutil.disk_usage(root).free
receipts=[]
def run(name,args):
    started=time.time(); peak=0
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        reason=None
        while p.poll() is None:
            mem=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()); peak=max(peak,mem)
            free=shutil.disk_usage(root).free
            if mem>14*2**30 or free<4*2**30 or start_free-free>12*2**30 or time.time()-started>1800:
                reason='resource/time admission exceeded'; os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
                break
            time.sleep(2)
        status=p.wait()
    receipts.append(dict(name=name,argv=args,exit=status,seconds=time.time()-started,peak_cgroup_bytes=peak,guard=reason))
    (out/'commands.json').write_text(json.dumps(receipts,indent=2))
    print(name,status,flush=True)
    return status
if run('build-xtask',['/workspace/.cargo/bin/cargo','build','--locked','-p','xtask']):raise SystemExit(1)
binary=str(root/'target/debug/xtask')
if run('check-all',[binary,'verdict-corpus','check-all']):raise SystemExit(1)
for lang in ['rust','typescript','python','perl']:
    if run('repeat-'+lang,[binary,'verdict-corpus','report','--language',lang,'--out',str(out/'repeat'/lang)]):raise SystemExit(1)
run('trust-gate',[binary,'dx-scoreboard','--boards','trust','--ripr-bin',str(root/'target/debug/ripr'),'--baseline','metrics/dx-scoreboard/baseline.json','--gate'])
