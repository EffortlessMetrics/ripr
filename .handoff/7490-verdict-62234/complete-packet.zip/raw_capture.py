import pathlib,subprocess,os,json,hashlib,collections,time
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-62234')
env=dict(os.environ,CARGO_NET_OFFLINE='true'); receipts=[]; counts=collections.Counter(); failures=[]
for lang in ['rust','typescript','python','perl']:
    corpus=root/f'fixtures/{lang}-verdict-corpus'; raw=out/'raw'/lang;raw.mkdir(parents=True,exist_ok=True)
    for casepath in sorted((corpus/'cases').glob('*.json')):
        case=json.loads(casepath.read_text()); cid=case['case_id']; work=root/'target/ripr/verdict-corpus'/lang/cid
        assert work.is_dir(),str(work)
        binary=out/'actors'/('ripr-lang-perl' if case.get('perl_facts') else 'ripr')
        args=[str(binary),'check','--root',str(work),'--diff',str(corpus/case['diff']),'--json']
        if case.get('perl_facts'):args+=['--perl-facts',str(corpus/case['perl_facts']['packet'])]
        selected_env=dict(env,RIPR_CACHE_DIR=str(out/'raw-cache'/lang/cid))
        start=time.time();p=subprocess.run(args,cwd=root,env=selected_env,capture_output=True,timeout=90)
        (raw/(cid+'.json')).write_bytes(p.stdout)
        if p.stderr:(raw/(cid+'.stderr')).write_bytes(p.stderr)
        try:
            value=json.loads(p.stdout); outcome=value['analysis_outcome']['outcome']; kind=outcome['kind'];counts[(lang,kind)]+=1
        except (ValueError,KeyError,TypeError):kind='unreadable';failures.append([lang,cid,'unreadable'])
        if p.returncode:failures.append([lang,cid,p.returncode])
        receipts.append(dict(language=lang,case_id=cid,argv=args,exit=p.returncode,seconds=time.time()-start,outcome=kind,stdout_bytes=len(p.stdout),stdout_sha256=hashlib.sha256(p.stdout).hexdigest(),stderr_bytes=len(p.stderr),stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
(out/'raw-receipts.json').write_text(json.dumps(receipts,indent=2))
(out/'raw-summary.json').write_text(json.dumps(dict(executed=len(receipts),outcomes={lang:{k:n for (l,k),n in counts.items() if l==lang} for lang in ['rust','typescript','python','perl']},failures=failures),indent=2))
print((out/'raw-summary.json').read_text())
raise SystemExit(bool(failures))
