import os, pathlib, subprocess, time, json, shutil, signal
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-62234')
env=dict(os.environ,PATH='/workspace/.cargo/bin:'+os.environ['PATH'],CARGO_HOME='/workspace/.cargo',RUSTUP_HOME='/workspace/.rustup',CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',RAYON_NUM_THREADS='1')
start_free=shutil.disk_usage(root).free
receipts=[]
def run(name,args):
    started=time.time(); peak=0
    with (out/(name+'.log')).open('w') as log:
        p=subprocess.Popen(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        reason=None
        while p.poll() is None:
            mem=int(pathlib.Path('/sys/fs/cgroup/memory.current').read_text()); peak=max(peak,mem)
            free=shutil.disk_usage(root).free
            if mem>14*2**30 or free<4*2**30 or start_free-free>12*2**30 or time.time()-started>1800:
                reason='resource/time admission exceeded'; os.killpg(p.pid,signal.SIGTERM)
                try:p.wait(timeout=5)
                except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
                break
            time.sleep(2)
        status=p.wait()
    receipts.append(dict(name=name,argv=args,exit=status,seconds=time.time()-started,peak_cgroup_bytes=peak,guard=reason))
    (out/'commands.json').write_text(json.dumps(receipts,indent=2))
    print(name,status,flush=True)
    return status

receipts=json.loads((out/'commands.json').read_text())
binary=str(root/'target/debug/xtask')
for lang in ['rust','typescript','python','perl']:
    if not (out/'repeat'/lang/'report.json').exists():
        run('repeat-'+lang,[binary,'verdict-corpus','report','--language',lang,'--out',str(out/'repeat'/lang)])
run('raw-capture',['python3',str(out/'raw_capture.py')])
run('integrity-controls',['/workspace/.cargo/bin/cargo','test','--locked','-p','xtask','--bin','xtask','--','population_tests','case_output_','spec_scope_files','ledger_must_name_every_spec','drift_names_moved_missing','--test-threads=1'])
run('runtime-controls',[binary,'verdict-corpus','relabel','--case','trap-const-fn-self-expected','--case','spec0231-oracle-helper-assert-json-eq','--case','spec0231-oracle-events-sent-len-eq','--case','spec0226-gate-split-boundary-agreement','--repeat','2','--out',str(out/'runtime-controls'),'--work-dir',str(out/'runtime-work')])
if not any(x['name']=='trust-gate' for x in receipts):
    run('trust-gate',[binary,'dx-scoreboard','--boards','trust','--ripr-bin',str(root/'target/debug/ripr'),'--baseline','metrics/dx-scoreboard/baseline.json','--gate'])
