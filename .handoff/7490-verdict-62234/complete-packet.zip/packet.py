exec(open('/workspace/scratch/verdict-62234/compare.py').read().split("current='622")[0])
candidate='62234ac13b0f7a8ff7e30d239f59215b808775b3'
ident=json.loads((out/'comparison-identities.json').read_text())
def totals(rows):
    truth=collections.Counter(r['truth'] for r in rows); outcomes=collections.Counter(r['outcome'] for r in rows)
    n=len(rows); d=truth['discriminated']; nd=n-d
    return dict(cases=n,subjects=len(set(r['subject_id'] for r in rows)),hard_cases=sum(r['hard_case'] for r in rows),truth=dict(truth),outcomes=dict(outcomes),observed=dict(collections.Counter(r['observed_verdict'] for r in rows)),false_verdict=[sum(outcomes[k] for k in ['false_actionable','false_exposed','false_silent']),n],false_actionable=[outcomes['false_actionable'],d],false_exposed=[outcomes['false_exposed'],nd],false_silent=[outcomes['false_silent'],nd],abstained=[outcomes['abstained'],n])
reports={}; summaries={}
for lang in ['rust','typescript','python','perl']:
    path=root/'target/ripr/reports/verdict-corpus'/('' if lang=='rust' else lang)/'report.json'
    r=json.loads(path.read_text()); repeat=json.loads((out/'repeat'/lang/'report.json').read_text())
    reports[lang]=r; summaries[lang]=dict(full=totals(r['rows']),stable_repeat=r==repeat,report_sha256=digest(path.read_bytes()),by_origin=r['by_origin'],by_packet_provenance=r.get('by_packet_provenance',{}),oracle=r.get('oracle_accuracy'),contradictions=r['contradiction_rate'],false_cases=[x for x in r['rows'] if x['outcome'].startswith('false_')])
    import shutil
    (out/'full'/lang).mkdir(parents=True,exist_ok=True)
    for ext in ['json','md']:shutil.copy(path.with_suffix('.'+ext),out/'full'/lang/('report.'+ext))
now={r['case_id']:r for r in reports['rust']['rows']}
comparisons={}
for rev,partition in ident['historical_partitions'].items():
    old={json.loads(read(rev,p))['case_id']:json.loads(read(rev,p)) for p in files(rev,'fixtures/rust-verdict-corpus/expected/rows/') if p.endswith('.json')}
    comparisons[rev]=dict(populations={k:len(v) for k,v in partition.items()},historical_full=totals(list(old.values())),unchanged_before=totals([old[c] for c in partition['unchanged']]),unchanged_after=totals([now[c] for c in partition['unchanged']]),changed_after=totals([now[c] for c in partition['changed']]),added_after=totals([now[c] for c in partition['added']]),movements=dict(collections.Counter(old[c]['outcome']+' -> '+now[c]['outcome'] for c in partition['unchanged'] if old[c]['outcome']!=now[c]['outcome'])))
original=json.loads((root/'benchmarks/dx_scoreboard/testdata/7552-original-baseline-with-population.json').read_text())
def pops(v):
    if isinstance(v,dict):
        if v.get('schema_version')=='ripr-verdict-case-population-v1':yield v
        for x in v.values():yield from pops(x)
    elif isinstance(v,list):
        for x in v:yield from pops(x)
original_pops=list(pops(original)); origids=[c['case_id'] for c in original_pops[0]['cases']]
changed=ident['original_population_validation'][0]['mismatches']
packet=dict(candidate=candidate,tree='ef7221a5c23a73670d23bc9998cfe1496b4e38f0',languages=summaries,historical_comparisons=comparisons,original203=dict(unchanged_cases=len(origids)-len(changed),changed_definitions=changed,unchanged_current=totals([now[c] for c in origids if c not in changed]),changed_current=totals([now[c] for c in changed]),all_original_current=totals([now[c] for c in origids])),limitations=['Historical baseline rows are committed observations, not freshly executed historical binaries.','Runtime mutation truth labels were not replayed by verdict-corpus check/report.','Authored cases and retained upstream excerpts are not a real-world accuracy population.','Abstentions remain in full counts and do not establish repaired discrimination.','This packet is evidence for adjudication, not qualification or ship authorization.'])
actors=json.loads((out/'actors.json').read_text())
packet['actors']=actors
packet['commands']=json.loads((out/'commands.json').read_text())
(out/'packet.json').write_text(json.dumps(packet,indent=2))
print(json.dumps({l:s['full']|dict(stable_repeat=s['stable_repeat']) for l,s in summaries.items()},indent=2))
