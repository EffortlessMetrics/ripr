# Perl verdict corpus report

Spec: RIPR-SPEC-0245. Cases: 94.

| Rate | Count | Rate |
| --- | --- | --- |
| False verdicts (all cases) | 0/94 | 0.0000 |
| False actionable (of discriminated) | 0/36 | 0.0000 |
| False exposed (of not fully discriminated) | 0/58 | 0.0000 |
| False silent (of not fully discriminated) | 0/58 | 0.0000 |
| Ideal verdict | 45/94 | 0.4787 |
| Abstained (limited or silent where acceptable) | 49/94 | 0.5213 |
| Findings with a contradiction | 0/94 | 0.0000 |

By fact-packet provenance. An edited packet changes named producer facts to reach a shape a spec defines that the producer does not emit today, so only the producer rates describe what a Perl user gets now.

| Packet | Cases | False verdicts | False actionable | False exposed | False silent | Ideal | Abstained |
| --- | --- | --- | --- | --- | --- | --- | --- |
| edited_producer | 34 | 0/34 | 0/6 | 0/28 | 0/28 | 28/34 | 6/34 |
| producer | 60 | 0/60 | 0/30 | 0/30 | 0/30 | 17/60 | 43/60 |

| Case | Origin | Truth | Ideal | Observed | Classes | Outcome | Changed since labeling | Contradictions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `perl-0235-ex01-sink-unconfirmed` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `perl-0235-ex03-smoke-ok-strong-exact` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex04-dies-only-strong-exact` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex05-exception-observer-strong-exact` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `perl-0235-ex06-hash-field-assertion` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex06-output-observer` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex07-like-weak-broad` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex08-mention-only` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex09-oracle-without-owner` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex10-relation-without-oracle` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex11-weakly-reachable-no-sink` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex12-static-unknown-hint` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-0235-ex13-method-receiver` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `perl-0235-ex14-helper-call` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `perl-0235-ex15-package-reference` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex15-test-name-match` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex16-no-relations-complete` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `perl-0235-ex16-no-relations` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-0235-ex17-aligned-sinks-complete-packet` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `perl-0235-ex18-reversed-sinks` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex19-sink-whitespace` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `perl-0235-ex20-method-receiver-aligned-sinks` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex21-weakly-reachable-aligned-sinks` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex23-missing-test-runner` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `perl-0235-ex24-framework-indirection` | authored | discriminated | credited | limited | weakly_exposed | abstained | no | none |
| `perl-0235-ex25-dynamic-dispatch` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-0235-ex26-partial-inference` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex27-file-proximity-control` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex27-weakly-reachable-and-package-reference` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-0235-ex28-cross-test-oracle` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex29-low-confidence-relation` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex29-unknown-framework` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex30-rangeless-owner-id` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-0235-ex31-unknown-owner-kind` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-bless-counter-inc` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-bless-counter-start` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-hostile-autoload-field` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-hostile-constant-tax` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-hostile-glob-double` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-hostile-glob-triple-unexercised` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `perl-hostile-heredoc-greeting` | authored | partially_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-hostile-line-directive-pad` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-hostile-string-eval-quad` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-hostile-unicode-sub-name` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-idiom-banner-repeat` | authored | partially_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-idiom-closure-counter` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-idiom-eval-safe-div` | authored | partially_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-idiom-local-separator` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-idiom-regex-version` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `perl-idiom-slugify-subst` | authored | partially_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-idiom-wantarray-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `perl-idiom-wantarray-smoke` | authored | partially_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-moose-birthday-smoke` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-moose-builder-join` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-moose-is-adult-boundary` | authored | partially_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-test2-close-month-subtest` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-test2-deposit-lives-only` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-test2-fee-isnt-zero` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-test2-format-entry-like` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-test2-net-change-imported` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-test2-overdrawn-ok-smoke` | authored | partially_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-test2-summary-deep-is-count` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `perl-test2-withdraw-dies-like-message` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testdeep-adjust-exact-hash` | authored | discriminated | credited | limited | reachable_unrevealed | abstained | no | none |
| `perl-testdeep-label-pair-code` | authored | partially_discriminated | gap | limited | reachable_unrevealed | abstained | no | none |
| `perl-testdeep-record-ignore` | authored | partially_discriminated | gap | limited | reachable_unrevealed | abstained | no | none |
| `perl-testdeep-restock-superhashof` | authored | not_discriminated | gap | limited | reachable_unrevealed | abstained | no | none |
| `perl-testdeep-sku-re` | authored | partially_discriminated | gap | limited | reachable_unrevealed | abstained | no | none |
| `perl-testdeep-tag-list-bag` | authored | partially_discriminated | gap | limited | reachable_unrevealed | abstained | no | none |
| `perl-testexception-class-only-message` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-testexception-class-then-message` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-testexception-close-out-dies-ok` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-testexception-eval-like-dollar-at` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `perl-testexception-eval-ok-no-error` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-testexception-freeze-class` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testexception-interest-lives-ok` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-testexception-lives-and-is` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `perl-testexception-lives-and-weak-ok` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-testexception-prefix-only-regex` | authored | partially_discriminated | gap | limited | static_unknown | abstained | no | none |
| `perl-testexception-transfer-boundary-pair` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testexception-withdraw-throws-message` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-bulk-subtest` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-bundle-helper-sub` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-can-ok-only` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `perl-testmore-cart-dynamic-dispatch` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-cart-method-total` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-clamp-isnt` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `perl-testmore-discount-imported-boundary` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-points-cmp-ok-positive` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `perl-testmore-quote-is-deeply-total` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-round-cents-like` | authored | partially_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-testmore-shipping-smoke-ok` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | no | none |
| `perl-testmore-tax-table-loop` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `perl-testmore-tier-far-from-boundary` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |

## Spec example coverage

Numbered acceptance examples of in-scope specs that at least one case cites in `spec_examples` (fixtures/perl-verdict-corpus/spec-coverage.toml). Covered 32/33 (0.9697); locked 32. Waived 0 and accounted (covered plus waived) 32/33. In-scope specs 1, out-of-scope specs 171.

Unmeasured in-scope specs (prose acceptance examples, not counted): RIPR-SPEC-0283, RIPR-SPEC-0291, RIPR-SPEC-0374, RIPR-SPEC-0375, RIPR-SPEC-0395, RIPR-SPEC-0420.

| Spec | In-scope examples | Covered | Waived | Uncovered |
| --- | --- | --- | --- | --- |
| RIPR-SPEC-0235 | 33 | 32 | 0 | 33 |

## Operator grid

Operator classes crossed with the runtime-mutant truth of the cases that land in them: `credited` (every listed mutant fails a test), `gap` (none does) and `partial` (some do). Covered 9/21 unwaived cells (fixtures/perl-verdict-corpus/spec-coverage.toml); floor 9. Waived 0.

Each cell reads `cases (ideal / abstained / false)`.

| Operator | credited | gap | partial |
| --- | --- | --- | --- |
| boundary | 5 (0 / 5 / 0) | 12 (10 / 2 / 0) | 2 (1 / 1 / 0) |
| equality | **uncovered** | **uncovered** | **uncovered** |
| logical | **uncovered** | **uncovered** | **uncovered** |
| arithmetic | 9 (1 / 8 / 0) | 25 (20 / 5 / 0) | **uncovered** |
| constant | 1 (0 / 1 / 0) | **uncovered** | **uncovered** |
| return_value | 1 (0 / 1 / 0) | 4 (4 / 0 / 0) | 1 (1 / 0 / 0) |
| deletion | **uncovered** | **uncovered** | **uncovered** |

## False-credit traps

Cases from a trap subject. A trap is a test that looks like it checks the change but cannot notice it; ripr should not credit it. A control is the paired test that does notice it. Trap floor 0; false-credit ceiling 0.

| Kind | Cases | Credited | Gap | Limited | Silent |
| --- | --- | --- | --- | --- | --- |
| trap | 0 | 0 | 0 | 0 | 0 |
| control | 0 | 0 | 0 | 0 | 0 |

Non-claims:

- Rates describe this corpus only; they are not a population estimate for Perl code or for ripr in general.
- Every subject is authored to fill a cell of ripr's Perl oracle and reach rules; its rates are not real-world rates.
- ripr does not parse Perl. Every verdict here is ripr's reading of a committed fact packet, so a wrong verdict can come from the producer's facts or from ripr's rules; the case reasoning says which.
- edited_producer cases measure ripr's rules on facts the pinned producer does not emit; they are not evidence about the producer.
- Truth comes from the listed hand-written mutants, not from exhaustive mutation; a discriminated label means every listed mutant made prove fail.
- The harness does not run Perl, prove, the fact producer, mutation testing, or any network access.
