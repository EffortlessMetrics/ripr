# TypeScript verdict corpus report

Spec: RIPR-SPEC-0245. Cases: 373.

| Rate | Count | Rate |
| --- | --- | --- |
| False verdicts (all cases) | 0/373 | 0.0000 |
| False actionable (of discriminated) | 0/212 | 0.0000 |
| False exposed (of not fully discriminated) | 0/161 | 0.0000 |
| False silent (of not fully discriminated) | 0/161 | 0.0000 |
| Ideal verdict | 323/373 | 0.8660 |
| Abstained (limited or silent where acceptable) | 50/373 | 0.1340 |
| Findings with a contradiction | 0/373 | 0.0000 |

| Case | Origin | Truth | Ideal | Observed | Classes | Outcome | Changed since labeling | Contradictions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `deco-audited-passthrough-value` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `deco-audited-side-effect-unread` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `deco-class-decorator-seal-unobserved` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `deco-decorator-wrapper-value` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `deco-memoize-cache-check-unobserved` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `deco-method-body-under-decorator` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `deco-property-error-message` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `deco-property-limit-boundary` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `hostile-block-comment-assertion` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `hostile-crlf-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `hostile-it-fails-inverted-oracle` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `hostile-line-comment-assertion` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `hostile-minified-line-pinned` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `hostile-minified-line-unexercised-sibling` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `hostile-same-name-imported-module` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `hostile-same-name-unimported-module` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `hostile-skipped-describe-sole-pin` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `hostile-skipped-test-sole-pin` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `hostile-syntax-invalid-sibling` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `hostile-tabs-no-final-newline` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `hostile-uncalled-helper-assertion` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `hostile-unicode-emoji-literal` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `hostile-unicode-identifier-body` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-age-not-tobe` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-awaited-resolves-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-cents-custom-matcher` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-coupon-tothrow-broad` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-discount-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-floating-resolves-unawaited` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `jest-mined-default-export-object` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-mined-local-noop-describe` | authored | not_discriminated | gap | limited | no_static_path | abstained | yes | none |
| `jest-mined-local-noop-test` | authored | not_discriminated | gap | limited | no_static_path | abstained | yes | none |
| `jest-mined-private-impl-dispatcher` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `jest-mined-suite-factory` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-mined-test-fn-reference` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-mined-tobe-identity` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-mined-tobeinstanceof-bound-local` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-mined-tobeinstanceof-error-twice` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-mined-tobeinstanceof` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-mined-toequal-copy-not-identity` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-mined-tomatchobject-bound-local` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-mined-tomatchobject-field` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-mined-tomatchobject-name-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-mock-fn-spread-object` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-notify-called-with` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-order-assert-in-then` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-price-resolves-tobe` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-quantity-tothrow-message` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-receipt-inline-snapshot` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-shipping-boundary-unpinned` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-sku-method-chain` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex01` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex02` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex03` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex04` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex05` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex06` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex07` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0234-ex10` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex11` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex12` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex13-error` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0234-ex13-globalthis-error` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex13-typeerror` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0234-ex15` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex16` | authored | not_discriminated | gap | limited | no_static_path | abstained | yes | none |
| `jest-spec0234-ex17-default` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex17-renamed` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex18` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex19` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex20` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex21` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0234-ex22` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0234-ex24` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex25` | authored | not_discriminated | gap | limited | weakly_exposed | abstained | no | none |
| `jest-spec0234-ex27` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex28` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0234-ex29` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `jest-spec0234-ex30` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0234-ex31` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `jest-spec0234-ex32` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0243-ex30-factory-db` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0243-ex33-two-files-one-mocked` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0246-ex03-spread-drops-field` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0246-ex04-foreach-two-literals` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0246-ex05-foreach-variable-element` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0246-ex07-then-rejection-handler` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `jest-spec0246-ex09-async-foreach` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `jest-spec0246-ex10-member-pin-then-toequal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0246-ex11-extend-identity-matcher` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0246-ex12-literal-expected-sets-field` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0246-ex13-loaded-input-drops-field` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0246-ex14-second-assertion-pins-field` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0246-ex19a-plural-weak-rows` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0246-ex19b-plural-zero-row` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0247-ex03-second-send` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0247-ex05-ship-cb-mock` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0247-ex05-spyon-send` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0247-ex09-empty-inline-snapshot` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0247-ex12-spyon-module-object` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-drop-fee-rebound` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0248-drop-fee-second-input` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-drop-fee-sign-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0248-drop-fee-zero-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0248-drop-fee` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-drop-flat` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-drop-literal-zero` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-multiplied-term` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0248-throw-message-term` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `jest-spec0249-ex03-subclass-of-pinned` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0249-ex05-wrapped-pin` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0249-ex06-fall-through-if` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0249-ex07-one-line-if` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0249-ex08-test-local-class` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0249-ex09-message-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0250-ex04-normalized-result` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0250-ex05-non-literal-expected` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0250-ex06-spread-after-field` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0251-ex02-default-binds-other` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `jest-spec0251-ex03-body-shadows-default` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `jest-spec0251-ex04-strong-pin-on-other-default` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0251-ex05-destructured-local` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0251-ex06-one-hop-local` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0251-ex07-default-drop-fee-nonzero` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0251-ex07-default-drop-fee-zero` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0256-ex02-two-entry-object` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0256-ex03-after-braced-if` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0256-ex04-braceless-if` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0256-ex05-direct-mock-call` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0256-ex06-called-times` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0258-ex02-describe-title` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0258-ex03-no-snapshot-file` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0258-ex04-hint` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `jest-spec0258-ex05-update-script` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0258-ex06-spaced-call` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0258-ex07-config-resolver` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0258-ex08-inline-projects` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `jest-spec0258-ex08-projects-key` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0262-ex02-vacuous-or-matcher` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0262-ex03-matcher-registered-twice` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-spec0262-ex04-negated-strict-matcher` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-stock-truthy-only` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `jest-tax-module-mocked` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `jest-then-owner-member` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `jest-then-owner-multiline` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `jest-tier-test-each-table` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-before-hook-count` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-before-hook-trimmed-name` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `mocha-bonus-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-clamp-unexercised-lower-arm` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-closeto-tolerance` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `mocha-describe-skip-sole-pin` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `mocha-done-callback-value` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-fee-assert-strictequal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-gold-boundary` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-include-substring` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `mocha-isopen-true-smoke` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `mocha-it-skip-sole-pin` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-label-throw-second-replaced-line` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-label-throw-uneven-longer-block` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-label-throw-uneven-shorter-block` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-limit-async-await` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-lineitem-deep-equal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-memo-throw-message` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-nested-context-added-price` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `mocha-nested-context-empty-total` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-nested-describe-boundary` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-nested-describe-heavy-rate` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-reserve-not-equal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `mocha-spec14-chai-throw-string` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-spec8-chai-to-equal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-spec8-chai-tobe` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `mocha-throw-class-changed` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-throw-message-reworded` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `mocha-title-throw-second-replaced-line` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-title-throw-uneven-shorter-block` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `mocha-weak-greaterthan-count` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `node-first-attempt-nonnegative-bound` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `node-it-skip-sole-pin` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `node-match-anchored-slug` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `node-mock-fn-payload` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `node-mock-fn-recipient` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `node-mock-method-call-removed` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `node-mock-method-count-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `node-ok-length-weak` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `node-queue-push-length` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `node-queue-shift-order` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `node-retry-last-error` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `node-retry-success-value` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `node-t-mock-attempt-bound` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `node-t-skip-inside-test` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `nodetest-bulk-ok-smoke` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `nodetest-charge-rejects-message` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-currency-throws-regex` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-invoice-field-deepstrictequal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-latefee-t-assert` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-legacy-equal-literal-one` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-member-subtest` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-receipt-legacy-deepequal` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-refund-throws-bare` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `nodetest-shipping-describe-it` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `nodetest-spec0234-ex23-await-test` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-spec0243-ex34-throws-anchored-regex` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-spec0243-ex35-rejects-message-changed` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-spec0247-ex07-legacy-equal-loose-owner` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `nodetest-spec0252-ex06-helper-assert-noop` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `nodetest-subtest-t2-assert-strictequal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-t-assert-deepstrictequal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-t-assert-equal-variable` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-t-assert-throws-regex-message` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `nodetest-t-bracket-assert` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `nodetest-tier-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `pw-describe-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `pw-expect-soft-second-term` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `pw-expect-tobe-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `pw-fixme-clamp-upper-bound` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `pw-fixture-add-amount` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `pw-fixture-empty-total` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `pw-loop-registered-rounding-mode` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `pw-loop-registered-scale` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `pw-step-heavy-parcel-threshold` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `pw-step-threshold-far-from-inputs` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `pw-toequal-sort-dropped` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `pw-tothrow-anchored-regex` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-arrow-const-export` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-as-const-lookup-other-key` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `shape-as-const-lookup-pinned-key` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `shape-async-catch-fallback-unexercised` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `shape-async-error-class-changed` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-async-message-extended-substring` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `shape-async-message-reworded` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-async-port-upper-bound-unexercised` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `shape-async-try-path-value` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-barrel-export-star-owner` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-barrel-namespace-reexport` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-barrel-renamed-reexport-weak` | authored | not_discriminated | gap | limited | infection_unknown | abstained | yes | none |
| `shape-base-method-pinned-through-label` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `shape-class-getter-boundary` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `shape-class-method-compound-assign` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-default-parameter-unexercised` | authored | not_discriminated | gap | limited | infection_unknown | abstained | yes | none |
| `shape-enum-branch-weight` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-enum-member-value-unread` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `shape-generator-upper-bound` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-generic-fallback-boundary` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-nullish-fallback-literal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-nullish-middle-operand` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `shape-private-method-through-public` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `shape-reduce-initial-value` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `shape-static-factory-formula` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `shape-static-factory-rounding` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `shape-subclass-override-unexercised` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `shape-template-plural-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-count-alias-argument-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-count-arguments-argument-change` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-count-block-alias-argument-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-count-computed-argument-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-count-nested-alias-argument-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-count-optional-argument-change` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-grid-arithmetic-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-arithmetic-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-arithmetic-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-arithmetic-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-grid-arithmetic-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-boundary-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-boundary-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-boundary-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-boundary-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-boundary-table` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-constant-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-constant-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-constant-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-constant-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-constant-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-delete-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-delete-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-delete-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-delete-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-delete-table` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-equality-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-equality-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-equality-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-equality-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-equality-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-logical-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-logical-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-logical-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-logical-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-logical-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-returns-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-grid-returns-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-grid-returns-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-returns-prefix` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-grid-returns-property` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-grid-returns-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-nodetest-audit-log` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-nodetest-charge-rate` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-nodetest-footer-unasserted` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `ts-nodetest-gold-discount-rate` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-nodetest-gold-threshold` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-nodetest-quantity-guard` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-nodetest-quote-shipping-term` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-nodetest-shipping-threshold` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-nodetest-silver-legacy-assert` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-nodetest-tax-self-computed` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-spec0248-ex12-identity-left` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-table-boundary-break` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-table-boundary-edit` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-table-boundary-one-sided` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-awaited-promise` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-dead-branch` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-edited-arm` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-empty-table` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-trap-filled-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-floating-promise` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `ts-trap-input-asserted` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-live-branch` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-mocked-send-args` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-mocked-send` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-trap-platform-guarded` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `ts-trap-platform-matched` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `ts-trap-registered` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-trap-result-asserted` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-rethrown-assert` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-trap-sibling-arm` | authored | not_discriminated | gap | gap | reachable_unrevealed | ideal | yes | none |
| `ts-trap-skip-option` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-trap-skipped-test` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `ts-trap-swallowed-assert` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-tautology` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `ts-trap-todo-test` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `ts-trap-truthy-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-unregistered` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `ts-trap-wrapped-swallow` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-trap-wrapped-through` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-vitest-add-line-message` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-vitest-bulk-threshold` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-vitest-checkout-notify` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-vitest-is-empty` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-vitest-line-total-reexport` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `ts-vitest-remove-line-message` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-vitest-summary-snapshot` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `ts-vitest-unit-price-table-other-key` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `ts-vitest-unit-price-table` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `unnum-0027-ex1-boundary-gap` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0027-ex3-dynamic-dispatch` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0027-ex4-unreferenced-sibling-owner` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `unnum-0095-ex2-barrel-name-collision` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `unnum-0095-ex3-two-hop-chain` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0095-ex4-directory-star-barrel` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0095-ex5-barrel-other-name` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `unnum-0097-ex2-object-payload` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0097-ex3-class-reference` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0097-ex5-camelcase-identifier` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0098-ex1-console-log-swallowed` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0098-ex2-return-value-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0098-ex3-non-owner-observer-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-orders-audit-logger-called-with` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `vitest-orders-label-snapshot` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-orders-order-field-strict-equal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-orders-spec0234-ex09a-vitest-import` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-orders-spec0234-ex09c-test-context-expect` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-orders-spec0234-ex26-spy-namespace` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-orders-stock-own-module-mocked` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `vitest-orders-tier-each-boundary-pinned` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `vitest-orders-total-relational-positive` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-orders-user-rejects-to-throw` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-partial-array-length` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-partial-asymmetric-any` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-partial-exact-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-partial-typeof-kind` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-spec0254-ex02-awaited-local` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-spec0254-ex03-unchanged-key` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `vitest-spec0254-ex04-value-to-null` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `vitest-spec0254-ex05-region-key` | authored | discriminated | credited | credited | exposed | ideal | no | none |

## Spec example coverage

Numbered acceptance examples of in-scope specs that at least one case cites in `spec_examples` (fixtures/typescript-verdict-corpus/spec-coverage.toml). Covered 162/164 (0.9878); locked 162. Waived 0 and accounted (covered plus waived) 162/164. In-scope specs 16, out-of-scope specs 156.

Unmeasured in-scope specs (prose acceptance examples, not counted): RIPR-SPEC-0283, RIPR-SPEC-0291, RIPR-SPEC-0374, RIPR-SPEC-0375, RIPR-SPEC-0395, RIPR-SPEC-0420.

| Spec | In-scope examples | Covered | Waived | Uncovered |
| --- | --- | --- | --- | --- |
| RIPR-SPEC-0027 | 4 | 4 | 0 | none |
| RIPR-SPEC-0095 | 5 | 5 | 0 | none |
| RIPR-SPEC-0097 | 5 | 5 | 0 | none |
| RIPR-SPEC-0098 | 3 | 3 | 0 | none |
| RIPR-SPEC-0243 | 48 | 48 | 0 | none |
| RIPR-SPEC-0246 | 19 | 19 | 0 | none |
| RIPR-SPEC-0247 | 13 | 13 | 0 | none |
| RIPR-SPEC-0248 | 13 | 13 | 0 | none |
| RIPR-SPEC-0249 | 9 | 9 | 0 | none |
| RIPR-SPEC-0250 | 7 | 6 | 0 | 7 |
| RIPR-SPEC-0251 | 7 | 7 | 0 | none |
| RIPR-SPEC-0252 | 7 | 7 | 0 | none |
| RIPR-SPEC-0254 | 5 | 5 | 0 | none |
| RIPR-SPEC-0256 | 6 | 6 | 0 | none |
| RIPR-SPEC-0258 | 9 | 8 | 0 | 9 |
| RIPR-SPEC-0262 | 4 | 4 | 0 | none |

## Operator grid

Operator classes crossed with the runtime-mutant truth of the cases that land in them: `credited` (every listed mutant fails a test), `gap` (none does) and `partial` (some do). Covered 21/21 unwaived cells (fixtures/typescript-verdict-corpus/spec-coverage.toml); floor 21. Waived 0.

Each cell reads `cases (ideal / abstained / false)`.

| Operator | credited | gap | partial |
| --- | --- | --- | --- |
| boundary | 27 (25 / 2 / 0) | 24 (19 / 5 / 0) | 13 (13 / 0 / 0) |
| equality | 4 (4 / 0 / 0) | 1 (1 / 0 / 0) | 1 (1 / 0 / 0) |
| logical | 3 (3 / 0 / 0) | 2 (1 / 1 / 0) | 1 (1 / 0 / 0) |
| arithmetic | 17 (15 / 2 / 0) | 13 (9 / 4 / 0) | 1 (1 / 0 / 0) |
| constant | 30 (24 / 6 / 0) | 17 (10 / 7 / 0) | 1 (1 / 0 / 0) |
| return_value | 68 (63 / 5 / 0) | 49 (38 / 11 / 0) | 3 (3 / 0 / 0) |
| deletion | 18 (16 / 2 / 0) | 9 (7 / 2 / 0) | 1 (1 / 0 / 0) |

## False-credit traps

Cases from a trap subject. A trap is a test that looks like it checks the change but cannot notice it; ripr should not credit it. A control is the paired test that does notice it. Trap floor 13; false-credit ceiling 0.

| Kind | Cases | Credited | Gap | Limited | Silent |
| --- | --- | --- | --- | --- | --- |
| trap | 13 | 0 | 9 | 4 | 0 |
| control | 12 | 10 | 0 | 2 | 0 |

Non-claims:

- Rates describe this corpus only; they are not a population estimate for TypeScript code or for ripr in general.
- Every subject is authored to cover a test-library oracle or reach rule (RIPR-SPEC-0027, RIPR-SPEC-0085, RIPR-SPEC-0243); the rates describe those cells, not real-world TypeScript tests.
- Truth comes from the listed mutants, not from exhaustive mutation; a discriminated label means every listed mutant made the test command fail.
- The harness does not run mutation testing, the TypeScript test runners, or any network access.
