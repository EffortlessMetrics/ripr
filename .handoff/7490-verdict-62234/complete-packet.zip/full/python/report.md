# Python verdict corpus report

Spec: RIPR-SPEC-0245. Cases: 385.

| Rate | Count | Rate |
| --- | --- | --- |
| False verdicts (all cases) | 0/385 | 0.0000 |
| False actionable (of discriminated) | 0/181 | 0.0000 |
| False exposed (of not fully discriminated) | 0/204 | 0.0000 |
| False silent (of not fully discriminated) | 0/204 | 0.0000 |
| Ideal verdict | 302/385 | 0.7844 |
| Abstained (limited or silent where acceptable) | 83/385 | 0.2156 |
| Findings with a contradiction | 0/385 | 0.0000 |

| Case | Origin | Truth | Ideal | Observed | Classes | Outcome | Changed since labeling | Contradictions |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `py-almost-default-value` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-almost-delta-band` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-almost-helper-receiver` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-almost-places-band` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-almost-places-none-default` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-almost-positional-delta-band` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-almost-spread-band` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-bands-decorated-owner` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-bands-longer-body` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-bands-method-owner` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-bands-non-literal-band` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-bands-positional-band-outside` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `py-bands-positional-band-within` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-bands-spread-band` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-blocks-account-clamp-one-line` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-blocks-account-clamp-second-line` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-blocks-wallet-clamp-second-line` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-absence-below-pinned-level` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-caplog-absence-either-clause` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-caplog-absence-messages-equal-added` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-absence-not-any-contains-added` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-absence-record-list-equal-added` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-absence-text-retry-added` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-absence-text-still-absent` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-caplog-reads-messages-either-wording` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-caplog-reads-messages-suffix` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-reads-messages-wording` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-reads-records-contains-suffix` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-caplog-reads-records-contains-wording` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-reads-records-getmessage-wording` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-caplog-reads-records-list-comprehension-wording` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-channels-capfd-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-channels-capture-before-owner` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-mock-abs-rewrite` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-mock-any-matcher` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-mock-argless-assert` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-mock-arith-wrap` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-channels-mock-assert-any-call` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-mock-assert-called-with-last` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-readouterr-local-after-owner` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-channels-stderr-read-as-out` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-write-text-other-param` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-channels-write-text-right-param` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-coarse-exact-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-coarse-residue` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-coarse-sign` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-coarse-text-length` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-conjuncts-and-all-weak` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-conjuncts-and-exact-elsewhere` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-conjuncts-and-exact-owner` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-conjuncts-not-exact` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-conjuncts-or-exact` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-control-bool-key-missing` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-control-paren-plain` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-derived-cancel` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-classattr` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-forwarder` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-input` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-derived-literal` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-derived-local` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-module` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-pytest-local` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-derived-reference` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-derived-setup` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-fixture-patch-autouse-conftest` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-fixture-patch-env-control` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-fixture-patch-requested-fixture` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-fixture-patch-unittest-setup` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-fixtures-deposit` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-fixtures-fee-boundary` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-fixtures-greeting-default` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-fixtures-report-file` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-fixtures-warning-stderr` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-arithmetic-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-arithmetic-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-arithmetic-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-arithmetic-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-grid-arithmetic-table` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-boundary-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-boundary-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-boundary-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-boundary-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-boundary-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-constant-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-constant-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-constant-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-constant-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-constant-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-delete-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-delete-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-delete-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-delete-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-delete-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-equality-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-equality-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-equality-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-equality-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-equality-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-logical-exact` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-logical-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-logical-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-logical-property` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-logical-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-returns-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-grid-returns-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-grid-returns-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-returns-prefix` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-grid-returns-property` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-grid-returns-table` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-guard-atoms-is-none-taken` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-guard-atoms-is-none-untaken` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-hostile-builtin-name-shadow` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-crlf-test-helper-assert` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-dead-version-branch` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-hostile-dynamic-dispatch` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `py-hostile-lambda-assignment` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-live-version-branch` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-module-constant-pinned` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-module-constant-unpinned` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-hostile-nested-function` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-nested-result-discarded` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-hostile-nested-return-side-effect` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-no-assertion-test` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-hostile-no-trailing-newline` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-same-name-other-module` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-hostile-same-name-tested-module` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-star-import-exported` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-hostile-star-import-no-all-private` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-hostile-star-import-no-all-public` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-star-import-unexported` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-hostile-tab-indentation` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-uncalled-dynamic-target` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-hostile-unicode-function-name` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-unicode-string` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hostile-very-long-line` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-hypothesis-absolute-reference` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-hypothesis-clamp-invariant` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-hypothesis-label-no-crash` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-hypothesis-mean-bounds` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `py-hypothesis-passing-threshold` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-approx-constant-outside-tolerance` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-approx-constant-within-tolerance` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-idioms-autouse-fixture-value` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-caplog-level` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-caplog-message` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-doctest-separator` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-doctest-short-input` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-idioms-hypothesis-round-trip` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-idioms-mock-guard-empty-input` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-mock-message-case` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-mock-return-unread` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-monkeypatch-env-default` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-idioms-parametrize-middle-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-parametrize-return` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-parametrize-top-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-patch-clock-offset` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-patch-clock-separator` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-plain-test-beside-doctest` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-raises-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-raises-match-text` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-idioms-skipped-test` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-idioms-unittest-setup-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-idioms-unittest-setup-sign` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-idioms-xfail-test` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-literals-key-get` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-literals-key-unobserved` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-literals-list-index-observed` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-literals-list-index-unobserved` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-literals-value-digit-adjacent` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-literals-value-sibling-equal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-literals-value-subscripted` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-literals-whole-collection` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-mocker-patch-caller-arithmetic` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `py-mocker-patch-edited-callee` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-mocker-patch-object-edited-callee` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-nested-idempotent-owner` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-nested-independent-outer-owner` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-nested-repeated-inner-owner` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-numpy-allclose-tolerance` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-assert-equal-import` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-numpy-assertpy-equal-to` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-numpy-patched-helper` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-shadowed-np` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-signed-hex-scalar` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-spaced-exec` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-tautology` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-numpy-under-raises` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-numpy-wide-hex-scalar` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-offsets-minus-boundary-hit` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-offsets-no-boundary-input` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-offsets-parametrized-no-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-offsets-parametrized-offset` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-offsets-plus-boundary-hit` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-props-chain-pins` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-props-idempotent-reversed` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-props-idempotent` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-props-literal-expected` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-props-loop-identity` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-props-loop-tuple-target` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-props-name-outside-loop` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-pytest-bulk-default` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-footer-unreferenced` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-pytest-gold-discount-rate` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-gold-threshold` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-label-case` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-points-divisor` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-quantity-guard` | authored | partially_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-pytest-quote-shipping-term` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-pytest-receipt-format` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-pytest-shipping-threshold` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-pytest-silver-parametrized` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-pytest-tax-self-computed` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-raises-bound-args-index` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-raises-bound-coarse-length` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-raises-bound-unittest-exception` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-raises-callable-match-kwarg` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-raises-callable-pytest` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-raises-callable-unittest` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-rivals-alias-import` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-rivals-own-import-credited` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-route-clients-factory-built-app` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-route-clients-fixture-own-app` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-route-clients-fixture-rival-app` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-route-clients-nested-fixture-app` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-shapes-async-default` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-async-filter-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-shapes-async-fixed-runner` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-shapes-comprehension-dict-swap` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-comprehension-filter` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-context-exit-record` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-context-exit-suppress` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-shapes-dataclass-classmethod-free` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-shapes-dataclass-default-rate` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-dataclass-property-boundary` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-shapes-dataclass-staticmethod-parse` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-dataclass-total-rewrite` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-decorator-log-name` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-shapes-decorator-loop-bound-slack` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-shapes-decorator-loop-bound` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `py-shapes-decorator-retry-count-slack` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-shapes-decorator-retry-count` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `py-shapes-decorator-wrapped-return` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-dunder-add` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-dunder-bool` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-shapes-dunder-eq-type-guard` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-dunder-lt-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-shapes-dunder-repr` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-dunder-str-precision` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-shapes-generator-bound` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-genexp-element` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-match-literal-arm` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-match-type-pattern` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-shapes-match-wildcard-arm` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-shapes-nested-comprehension-filter` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-shapes-package-export-lookup` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-relative-import-missing-tier` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-shapes-relative-import-quote` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-shapes-relative-import-table` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0201-ex01-construct-and-render-self-call` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0201-ex02-same-class-name-from-other-module` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-spec0201-ex03-import-without-construct` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-spec0201-ex04-test-calls-helper-directly` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0201-ex05-module-function-builds-class-internally` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0201-ex06-six-hop-self-chain` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex01-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex02-not-equal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex03-assert-not-equal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex04-isinstance` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex05-and-chain` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex06-self-compare` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-spec0233-ex07-approx` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex08-almost-equal` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex09-mock-arg` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex09-mock-sign` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex10-numpy-helper` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex11-fluent-helper` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `py-spec0233-ex12-exact-then-other` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex13-other-then-exact` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex14-raises-class-edit` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex14-raises-match` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex15-raises-broad` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex16-value-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex17-raises-match-and-value` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex18-split-tests` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex19-match-anything` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex20-raises-regex` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex21-exc-value` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex22-dict-field` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex22-dict-whole` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex23-list-index` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex24-method-bound` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0233-ex24-method-orthogonal` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-spec0233-ex25-rival-import` | authored | not_discriminated | gap | limited | no_static_path | abstained | yes | none |
| `py-spec0233-ex26-call-named-type` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex27-module-imports-os` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex28-lambda-in-string` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex29-client-patch` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-spec0233-ex30-property` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `py-spec0233-ex31-fstring-length` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-spec0233-ex32-split-dict` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-spec0233-ex33-key-lambda-no-arg` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `py-spec0233-ex33-spaced-getattr` | authored | discriminated | credited | limited | static_unknown | abstained | yes | none |
| `py-spec0233-ex34-exc-length` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0233-ex34-exc-not-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0238-ex39-boundary-change-given` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0260-ex01-guard-excludes-observed-input` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-spec0260-ex02-guard-satisfied-by-observed-input` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0260-ex03-or-guard-fails-open` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0260-ex04-rebound-parameter-before-guard` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-spec0260-ex05-bool-argument-equals-one` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-bool-key-fallback` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-conditional-exit` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-dead-branch` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-trap-edited-arm` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-empty-table` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-trap-exit-before-assert` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-trap-filled-table` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-foreign-store` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-input-asserted` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-live-branch` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-message-asserted` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-misnamed-test` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-trap-mocked-send-args` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-mocked-send` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-module-loaded` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-module-skipped` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-trap-named-test` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-patched-owner` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-platform-guarded` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-trap-platform-matched` | authored | discriminated | credited | limited | no_static_path | abstained | no | none |
| `py-trap-reraised-assert` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-result-asserted` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-trap-shadowed-test` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-trap-sibling-arm` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-skipif-false` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-trap-skipped-test` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-star-imported` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-trap-swallowed-assert` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | yes | none |
| `py-trap-tautology` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-truthy-only` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-tuple-asserted` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-trap-unused-helper` | authored | not_discriminated | gap | limited | no_static_path | abstained | no | none |
| `py-trap-wrapped-conditional` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-wrapped-finally` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-wrapped-partial` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-trap-wrapped-swallow` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-trap-wrapped-through` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-trap-xfail-test` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-uncollected-addopts-ignore` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-uncollected-class-switch-inherited` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-uncollected-class-switch-true` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-uncollected-class-switch` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-uncollected-conftest-ignore` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-uncollected-module-switch` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-uncollected-python-files-match` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-uncollected-python-files` | authored | not_discriminated | gap | limited | static_unknown | abstained | yes | none |
| `py-unittest-can-withdraw` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unittest-deposit-add` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-unittest-fee-waiver-mixin` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-unittest-overdraft-boundary` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unittest-owner-strip` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unittest-transfer-notify` | authored | discriminated | credited | credited | exposed | ideal | yes | none |
| `py-unrun-dead-else-read` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-unrun-dead-if-none` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-dead-if-zero` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-dead-while-false` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-empty-tuple-table` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-unrun-importorskip-missing` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-unrun-module-pytestmark-skip` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-unrun-module-skip-call` | authored | not_discriminated | gap | limited | static_unknown | abstained | no | none |
| `py-unrun-swallow-bare` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-swallow-builtins` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-swallow-else-read` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-unrun-swallow-fail-helper` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-unrun-swallow-finally-read` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-unrun-swallow-tuple` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `py-unrun-unittest-skipunless-true` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `py-unrun-xfail-false-active` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0028-ex1-boundary-gap` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0028-ex2-raises-error-path` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0028-ex3-decorator-indirection` | authored | discriminated | credited | limited | static_unknown | abstained | no | none |
| `unnum-0028-ex4a-lru-cache-direct-pin` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0028-ex4b-lru-cache-unobserved-return` | authored | not_discriminated | gap | gap | weakly_exposed | ideal | no | none |
| `unnum-0028-ex5-override-marker` | authored | discriminated | credited | credited | exposed | ideal | no | none |
| `unnum-0028-ex6-route-decorator` | authored | discriminated | credited | credited | exposed | ideal | no | none |

## Spec example coverage

Numbered acceptance examples of in-scope specs that at least one case cites in `spec_examples` (fixtures/python-verdict-corpus/spec-coverage.toml). Covered 62/62 (1.0000); locked 62. Waived 0 and accounted (covered plus waived) 62/62. In-scope specs 4, out-of-scope specs 168.

Unmeasured in-scope specs (prose acceptance examples, not counted): RIPR-SPEC-0004, RIPR-SPEC-0035, RIPR-SPEC-0283, RIPR-SPEC-0291, RIPR-SPEC-0374, RIPR-SPEC-0375, RIPR-SPEC-0395, RIPR-SPEC-0420.

| Spec | In-scope examples | Covered | Waived | Uncovered |
| --- | --- | --- | --- | --- |
| RIPR-SPEC-0028 | 6 | 6 | 0 | none |
| RIPR-SPEC-0201 | 6 | 6 | 0 | none |
| RIPR-SPEC-0238 | 43 | 43 | 0 | none |
| RIPR-SPEC-0260 | 7 | 7 | 0 | none |

## Operator grid

Operator classes crossed with the runtime-mutant truth of the cases that land in them: `credited` (every listed mutant fails a test), `gap` (none does) and `partial` (some do). Covered 21/21 unwaived cells (fixtures/python-verdict-corpus/spec-coverage.toml); floor 21. Waived 0.

Each cell reads `cases (ideal / abstained / false)`.

| Operator | credited | gap | partial |
| --- | --- | --- | --- |
| boundary | 18 (17 / 1 / 0) | 21 (16 / 5 / 0) | 2 (2 / 0 / 0) |
| equality | 3 (3 / 0 / 0) | 1 (1 / 0 / 0) | 1 (1 / 0 / 0) |
| logical | 3 (3 / 0 / 0) | 1 (1 / 0 / 0) | 1 (1 / 0 / 0) |
| arithmetic | 28 (24 / 4 / 0) | 35 (18 / 17 / 0) | 1 (1 / 0 / 0) |
| constant | 34 (32 / 2 / 0) | 48 (26 / 22 / 0) | 1 (1 / 0 / 0) |
| return_value | 43 (41 / 2 / 0) | 34 (23 / 11 / 0) | 1 (1 / 0 / 0) |
| deletion | 7 (7 / 0 / 0) | 1 (1 / 0 / 0) | 1 (1 / 0 / 0) |

## False-credit traps

Cases from a trap subject. A trap is a test that looks like it checks the change but cannot notice it; ripr should not credit it. A control is the paired test that does notice it. Trap floor 25; false-credit ceiling 0.

| Kind | Cases | Credited | Gap | Limited | Silent |
| --- | --- | --- | --- | --- | --- |
| trap | 25 | 0 | 10 | 15 | 0 |
| control | 15 | 14 | 0 | 1 | 0 |

Non-claims:

- Rates describe this corpus only; they are not a population estimate for Python code or for ripr in general.
- Every subject is authored to cover a test-library oracle or reach rule; the rates describe those cells, not real-world Python tests.
- Truth comes from the listed mutants, not from exhaustive mutation; a discriminated label means every listed mutant made the test command fail.
- The harness does not run mutation testing, the Python test runners, or any network access.
