# ripr developer-experience scoreboards

Revision `62234ac13b0f7a8ff7e30d239f59215b808775b3` · ripr 0.11.0 (62234ac13b0f7a8ff7e30d239f59215b808775b3) · runner `local-linux-x86_64-4cpu-amd-epyc-9v74-80-core-processor`

**Rollup:** 19 meet target, 2 below target, 7 not measured, 0 failed, 0 regressed, 1 not compared. Gate: `fail`.


**Comparison failed** `trust.perl_verdict_corpus_false_verdict`: no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence

**Comparison failed** `trust.perl_verdict_corpus_false_actionable`: no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence

**Comparison failed** `trust.perl_verdict_corpus_false_exposed`: no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence

**Comparison failed** `trust.perl_verdict_corpus_false_silent`: no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence

**Comparison failed** `trust.perl_verdict_corpus_abstention`: no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence
**Not compared with the baseline (outside this gate run):**

- `trust.self_contradictions`: baseline or current value is missing

| Board | Status | Meets | Below | Not measured |
|---|---|---:|---:|---:|
| trust | attention | 19 | 2 | 7 |

## trust

| Metric | Value | Target | Status | Baseline |
|---|---:|---:|---|---|
| Commands that exit 0 when pointed at a missing repository (`trust.false_clean_on_bad_input`) | 0 | ≤ 0 | meets_target | 0 (Δ 0) ok |
| Hostile-repository journeys (odd file names, symlink loops, shallow clones, submodules) where ripr neither finds nor refuses cleanly (`trust.hostile_repo_failures`) | 0 | ≤ 0 | meets_target | 0 (Δ 0) ok |
| Findings or seams whose own evidence contradicts itself (`trust.self_contradictions`) | — | ≤ 0 | not_measured | baseline or current value is missing |
| Editor-server resilience checks that failed (save burst, restart after termination) (`trust.editor_resilience_failures`) | — | ≤ 0 | not_measured | metric absent from baseline |
| Wrong verdicts on the hand-checked verdict corpus (`trust.false_verdict_rate`) | 0 | ≤ 0.05 | meets_target | common 448 cases: 28/448 → 0/448 ok; added 369 (0/369), removed 0, changed definitions 29 |
| Hand-checked edits the crate's tests fully catch that ripr still flags as a gap (`trust.verdict_corpus_false_actionable`) | 0 | ≤ 0.05 | meets_target | common 448 cases: 25/225 → 0/225 ok; added 369 (0/200), removed 0, changed definitions 29 |
| Hand-checked edits where ripr gives no specific verdict (`trust.verdict_corpus_abstention`) | 0.379 | ≤ 0.2 | below_target | common 448 cases: 168/448 → 141/448 ok; added 369 (169/369), removed 0, changed definitions 29 |
| Hand-checked edits the crate's tests miss that ripr reports as fine (counterweight to abstaining less) (`trust.verdict_corpus_false_silent`) | 0 | ≤ 0 | meets_target | common 448 cases: 0/223 → 0/223 ok; added 369 (0/169), removed 0, changed definitions 29 |
| Hand-checked edits the crate's tests miss that ripr credits as caught (false confidence; few credited cases so far, so read with its denominator) (`trust.verdict_corpus_false_exposed`) | 0 | ≤ 0 | meets_target | common 448 cases: 3/223 → 0/223 ok; added 369 (0/169), removed 0, changed definitions 29 |
| Authored TypeScript edits the project's tests fully catch that ripr still flags as a gap (`trust.verdict_corpus_typescript_false_actionable`) | 0 | ≤ 0.05 | meets_target | common 105 cases: 2/69 → 0/69 ok; added 204 (0/111), removed 0, changed definitions 64 |
| Authored TypeScript edits the project's tests miss that ripr credits as caught (`trust.verdict_corpus_typescript_false_exposed`) | 0 | ≤ 0 | meets_target | common 105 cases: 0/36 → 0/36 ok; added 204 (0/93), removed 0, changed definitions 64 |
| Authored TypeScript edits the project's tests miss that ripr reports as fine (`trust.verdict_corpus_typescript_false_silent`) | 0 | ≤ 0 | meets_target | common 105 cases: 0/36 → 0/36 ok; added 204 (0/93), removed 0, changed definitions 64 |
| In-scope numbered spec acceptance examples (minus waived) that a runtime-labeled verdict-corpus case cites (`trust.verdict_corpus_spec_example_coverage`) | 1 | ≥ 1 | meets_target | 1 (Δ 0) ok |
| Authored Python edits the project's tests fully catch that ripr still flags as a gap (`trust.verdict_corpus_python_false_actionable`) | 0 | ≤ 0.05 | meets_target | common 31 cases: 0/13 → 0/13 ok; added 316 (0/146), removed 0, changed definitions 38 |
| Authored Python edits the project's tests miss that ripr credits as caught (`trust.verdict_corpus_python_false_exposed`) | 0 | ≤ 0 | meets_target | common 31 cases: 0/18 → 0/18 ok; added 316 (0/170), removed 0, changed definitions 38 |
| Authored Python edits the project's tests miss that ripr reports as fine (`trust.verdict_corpus_python_false_silent`) | 0 | ≤ 0 | meets_target | common 31 cases: 0/18 → 0/18 ok; added 316 (0/170), removed 0, changed definitions 38 |
| Wrong Perl verdicts on the hand-checked Perl verdict corpus (producer packets) (`trust.perl_verdict_corpus_false_verdict`) | 0 | ≤ 0.05 | meets_target | common 0 cases: 0/0 → 0/0 no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence; added 6 (0/6), removed 0, changed definitions 88 |
| Hand-checked Perl edits the tests fully catch that ripr still flags as a gap (producer packets) (`trust.perl_verdict_corpus_false_actionable`) | 0 | ≤ 0.05 | meets_target | common 0 cases: 0/0 → 0/0 no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence; added 6 (0/2), removed 0, changed definitions 88 |
| Hand-checked Perl edits the tests miss that ripr credits as caught (producer packets) (`trust.perl_verdict_corpus_false_exposed`) | 0 | ≤ 0 | meets_target | common 0 cases: 0/0 → 0/0 no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence; added 6 (0/4), removed 0, changed definitions 88 |
| Hand-checked Perl edits the tests miss that ripr reports as fine (producer packets) (`trust.perl_verdict_corpus_false_silent`) | 0 | ≤ 0 | meets_target | common 0 cases: 0/0 → 0/0 no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence; added 6 (0/4), removed 0, changed definitions 88 |
| Hand-checked Perl edits where ripr gives no specific verdict (producer packets) (`trust.perl_verdict_corpus_abstention`) | 0.717 | ≤ 0.2 | below_target | common 0 cases: 0/0 → 0/0 no eligible unchanged common cases; additions, removals and changed definitions cannot substitute for comparison evidence; added 58 (27/33), removed 0, changed definitions 36 |
| Verdict-corpus cases with a spec-adopted related-test oracle where ripr reports the same oracle kind and strength (`trust.verdict_corpus_oracle_accuracy`) | 1 | ≥ 1 | meets_target | common 459 cases: 44/44 → 44/44 ok; added 358 (5/5), removed 0, changed definitions 29 |
| Verdict-corpus cases with a spec-adopted related-test oracle where ripr reports a stronger oracle than the spec adopts (`trust.verdict_corpus_oracle_overclaim_rate`) | 0 | ≤ 0 | meets_target | common 459 cases: 0/44 → 0/44 ok; added 358 (0/5), removed 0, changed definitions 29 |
| When ripr says a test discriminates, real mutants are caught (`trust.discriminator_claim_agreement`) | — | ≥ 0.95 | not_measured | baseline was not ingested from a ripr-mutation-spot-check-v2 receipt |
| When ripr reports a gap, real mutants survive (`trust.gap_claim_agreement`) | — | ≥ 0.8 | not_measured | baseline was not ingested from a ripr-mutation-spot-check-v2 receipt |
| When ripr pilot ranks a seam in its top ten, a real mutant there is missed (`trust.pilot_top_recommendation_precision`) | — | ≥ 0.6 | not_measured | baseline was not ingested from a ripr-mutation-spot-check-v2 receipt |
| Real mutants that join a ripr seam precisely enough to score (`trust.mutation_join_coverage`) | — | ≥ 0.5 | not_measured | baseline was not ingested from a ripr-mutation-spot-check-v2 receipt |
| False actionable rate on the Rust judged behavior panel (`trust.judged_panel_false_actionable`) | — | ≤ 0 | not_measured | baseline or current value is missing |

`trust.false_clean_on_bad_input` (commands):
- all: 0 (meets_target) all 12 probes refused

`trust.hostile_repo_failures` (journeys):
- all: 0 (meets_target) 39 of 39 hostile-input journeys pass

`trust.self_contradictions` (findings):
- serde: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/serde; rerun with --clone to fetch the pinned corpus
- ripgrep: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/ripgrep; rerun with --clone to fetch the pinned corpus
- regex: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/regex; rerun with --clone to fetch the pinned corpus
- serde-no-rust: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/serde-no-rust; rerun with --clone to fetch the pinned corpus
- click-python: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/click-python; rerun with --clone to fetch the pinned corpus
- defu-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/defu-typescript; rerun with --clone to fetch the pinned corpus
- ky-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/ky-typescript; rerun with --clone to fetch the pinned corpus
- h3-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/h3-typescript; rerun with --clone to fetch the pinned corpus
- execa-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/execa-typescript; rerun with --clone to fetch the pinned corpus
- destr-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/destr-typescript; rerun with --clone to fetch the pinned corpus
- zod-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/zod-typescript; rerun with --clone to fetch the pinned corpus
- valibot-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/valibot-typescript; rerun with --clone to fetch the pinned corpus
- remeda-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/remeda-typescript; rerun with --clone to fetch the pinned corpus
- hono-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/hono-typescript; rerun with --clone to fetch the pinned corpus

`trust.editor_resilience_failures` (checks):
- serde: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/serde; rerun with --clone to fetch the pinned corpus
- ripgrep: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/ripgrep; rerun with --clone to fetch the pinned corpus
- regex: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/regex; rerun with --clone to fetch the pinned corpus
- serde-no-rust: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/serde-no-rust; rerun with --clone to fetch the pinned corpus
- click-python: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/click-python; rerun with --clone to fetch the pinned corpus
- defu-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/defu-typescript; rerun with --clone to fetch the pinned corpus
- ky-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/ky-typescript; rerun with --clone to fetch the pinned corpus
- h3-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/h3-typescript; rerun with --clone to fetch the pinned corpus
- execa-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/execa-typescript; rerun with --clone to fetch the pinned corpus
- destr-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/destr-typescript; rerun with --clone to fetch the pinned corpus
- zod-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/zod-typescript; rerun with --clone to fetch the pinned corpus
- valibot-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/valibot-typescript; rerun with --clone to fetch the pinned corpus
- remeda-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/remeda-typescript; rerun with --clone to fetch the pinned corpus
- hono-typescript: — (not_measured) no checkout at target/ripr/dx-scoreboard/corpus/hono-typescript; rerun with --clone to fetch the pinned corpus

`trust.false_verdict_rate` (ratio):
- all: 0 (meets_target) fixtures/rust-verdict-corpus false_verdict_rate: 0/846; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_false_actionable` (ratio):
- all: 0 (meets_target) fixtures/rust-verdict-corpus false_actionable_rate: 0/433; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_abstention` (ratio):
- all: 0.379 (below_target) fixtures/rust-verdict-corpus abstention_rate: 321/846; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_false_silent` (ratio):
- all: 0 (meets_target) fixtures/rust-verdict-corpus false_silent_rate: 0/413; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_false_exposed` (ratio):
- all: 0 (meets_target) fixtures/rust-verdict-corpus false_exposed_rate: 0/413; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_typescript_false_actionable` (ratio):
- all: 0 (meets_target) fixtures/typescript-verdict-corpus false_actionable_rate: 0/212; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_typescript_false_exposed` (ratio):
- all: 0 (meets_target) fixtures/typescript-verdict-corpus false_exposed_rate: 0/161; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_typescript_false_silent` (ratio):
- all: 0 (meets_target) fixtures/typescript-verdict-corpus false_silent_rate: 0/161; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_spec_example_coverage` (ratio):
- all: 1 (meets_target) fixtures/rust-verdict-corpus spec_example_coverage.coverage: 330/330

`trust.verdict_corpus_python_false_actionable` (ratio):
- all: 0 (meets_target) fixtures/python-verdict-corpus false_actionable_rate: 0/181; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_python_false_exposed` (ratio):
- all: 0 (meets_target) fixtures/python-verdict-corpus false_exposed_rate: 0/204; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_python_false_silent` (ratio):
- all: 0 (meets_target) fixtures/python-verdict-corpus false_silent_rate: 0/204; committed expected records, not fresh analyzer execution

`trust.perl_verdict_corpus_false_verdict` (ratio):
- all: 0 (meets_target) fixtures/perl-verdict-corpus by_packet_provenance.producer.false_verdict_rate: 0/60; committed expected records, not fresh analyzer execution

`trust.perl_verdict_corpus_false_actionable` (ratio):
- all: 0 (meets_target) fixtures/perl-verdict-corpus by_packet_provenance.producer.false_actionable_rate: 0/30; committed expected records, not fresh analyzer execution

`trust.perl_verdict_corpus_false_exposed` (ratio):
- all: 0 (meets_target) fixtures/perl-verdict-corpus by_packet_provenance.producer.false_exposed_rate: 0/30; committed expected records, not fresh analyzer execution

`trust.perl_verdict_corpus_false_silent` (ratio):
- all: 0 (meets_target) fixtures/perl-verdict-corpus by_packet_provenance.producer.false_silent_rate: 0/30; committed expected records, not fresh analyzer execution

`trust.perl_verdict_corpus_abstention` (ratio):
- all: 0.717 (below_target) fixtures/perl-verdict-corpus by_packet_provenance.producer.abstention_rate: 43/60; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_oracle_accuracy` (ratio):
- all: 1 (meets_target) fixtures/rust-verdict-corpus oracle_accuracy.oracle_accuracy: 49/49; committed expected records, not fresh analyzer execution

`trust.verdict_corpus_oracle_overclaim_rate` (ratio):
- all: 0 (meets_target) fixtures/rust-verdict-corpus oracle_accuracy.oracle_overclaim_rate: 0/49; committed expected records, not fresh analyzer execution

`trust.discriminator_claim_agreement` (ratio):
- not measured: no --ingest file supplied for `ingest:mutation-spot-check`

`trust.gap_claim_agreement` (ratio):
- not measured: no --ingest file supplied for `ingest:mutation-spot-check`

`trust.pilot_top_recommendation_precision` (ratio):
- not measured: no --ingest file supplied for `ingest:mutation-spot-check`

`trust.mutation_join_coverage` (ratio):
- not measured: no --ingest file supplied for `ingest:mutation-spot-check`

`trust.judged_panel_false_actionable` (ratio):
- all: — (not_measured) metrics/rust-judged-behavior-panel/calibration-scorecard.json candidates.false_actionable: denominator is 0, no eligible cases yet

## Claim boundary

Numbers hold for the recorded revision, binary, runner class and pinned corpus only. Targets are proposed bars, not product guarantees. Wall-time and memory metrics are compared only against a baseline from the same runner class; peak memory is sampled from /proc every 10 ms on Linux and is a lower bound. Static verdict metrics do not claim runtime mutation outcomes.
