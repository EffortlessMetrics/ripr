"""Recover collector metadata from original byte-verified CLI outputs; no rerun."""
from pathlib import Path
import collections,hashlib,json
p=Path('/workspace/scratch/verdict-62234'); root=Path('/workspace/ripr-swarm')
receipts=json.loads((p/'raw-receipts.json').read_text()); counts=collections.Counter()
for r in receipts:
    b=(p/'raw'/r['language']/(r['case_id']+'.json')).read_bytes()
    assert len(b)==r['stdout_bytes'] and hashlib.sha256(b).hexdigest()==r['stdout_sha256']
    v=json.loads(b);o=v['analysis_outcome']['outcome'];kind=o['kind']
    assert kind in ['complete_with_findings','complete_no_findings','partial_with_limitations','no_behavioral_candidates']
    assert r['exit']==0
    c=json.loads((root/f"fixtures/{r['language']}-verdict-corpus/cases"/(r['case_id']+'.json')).read_text())
    diff=(root/f"fixtures/{r['language']}-verdict-corpus"/c['diff']).read_bytes()
    assert o['identity']['input_identity']=='sha256:'+hashlib.sha256(diff).hexdigest()
    routed=[x for x in v['summary']['changed_files_by_language'] if x['language']==r['language']]
    completeness=[x for x in v['language_completeness']['languages'] if x['language']==r['language']]
    assert len(routed)==1 and len(completeness)==1
    assert completeness[0]['status'] in ['complete','complete_zero','partial']
    r['outcome']=kind;r['collector_postprocessed_from_retained_bytes']=True
    counts[(r['language'],kind)]+=1
(p/'raw-receipts.json').write_text(json.dumps(receipts,indent=2))
summary=dict(executed=len(receipts),outcomes={l:{k:n for (lang,k),n in counts.items() if lang==l} for l in ['rust','typescript','python','perl']},native_nonzero=0,failures=[],collector_note='Initial collector exit 1 read analysis_outcome.kind instead of analysis_outcome.outcome.kind. Original metadata, all native statuses and output bytes/digests retained. Corrected metadata derived from the same bytes with full diff-identity/routing/completeness checks; no analyzer rerun.',legitimate_zero_cases=sum(n for (l,k),n in counts.items() if k=='no_behavioral_candidates'))
(p/'raw-summary.json').write_text(json.dumps(summary,indent=2))
(p/'raw-reparse.json').write_text(json.dumps(dict(exit=0,verified_raw_outputs=len(receipts),sha256_input_identity_routing_completeness_verified=True),indent=2))
print(json.dumps(summary,indent=2))
