"""Analytical packet-custody challenges; not an analyzer or corpus scorer."""
import pathlib,json,copy,hashlib,subprocess
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-62234')
sha='62234ac13b0f7a8ff7e30d239f59215b808775b3';tree='ef7221a5c23a73670d23bc9998cfe1496b4e38f0'
def digest(b):return hashlib.sha256(b).hexdigest()
expected_defs=json.loads((out/'definitions.json').read_text())
expected_inventory='40bebd79b5bf5e3587fa8653d1fc344c88e1ceb8f0daffa7d75bfe16bc481cad'
reports={l:json.loads((out/'full'/l/'report.json').read_text()) for l in expected_defs}
receipts=json.loads((out/'raw-receipts.json').read_text())
evidence=dict(candidate=sha,tree=tree,corpus_inventory=digest((out/'corpus-inventory.txt').read_bytes()),definitions=copy.deepcopy(expected_defs),reports=reports,raw=receipts)
def audit(e):
    assert e['candidate']==sha and e['tree']==tree,'stale source'
    assert e['corpus_inventory']==expected_inventory,'corpus inventory mismatch'
    assert e['definitions']==expected_defs,'changed scoring expectation/definition'
    assert e['raw'],'zero executed rows'
    for lang,definitions in expected_defs.items():
        rows=e['reports'][lang]['rows']; ids=[r['case_id'] for r in rows]
        assert len(ids)==len(set(ids)) and set(ids)==set(definitions),'missing/dropped/duplicate case'
        actual=[r for r in e['raw'] if r['language']==lang]; rawids=[r['case_id'] for r in actual]
        assert len(rawids)==len(set(rawids)) and set(rawids)==set(definitions),'raw execution population mismatch'
        assert all(r['exit']==0 and r['outcome']!='unreadable' for r in actual),'failed/incomplete execution'
    pins={'trap-const-fn-self-expected':('not_discriminated','gap','ideal'),'spec0231-oracle-helper-assert-json-eq':('discriminated','credited','ideal')}
    rows={r['case_id']:r for r in e['reports']['rust']['rows']}
    for cid,pin in pins.items():
        r=rows[cid];assert (r['truth'],r['observed_verdict'],r['outcome'])==pin,'former false-exposed/false-actionable control changed; abstention is not repaired credit'
    return True
assert audit(evidence)
challenges=[]
def challenge(name,edit):
    e=copy.deepcopy(evidence);edit(e)
    try:audit(e)
    except AssertionError as err:challenges.append(dict(name=name,rejected=True,reason=str(err)))
    else:raise AssertionError('audit accepted '+name)
challenge('dropped case',lambda e:e['reports']['rust']['rows'].pop())
challenge('changed scoring expectation',lambda e:e['definitions']['rust'][next(iter(e['definitions']['rust']))].update(hash='0'*64))
challenge('stale candidate',lambda e:e.update(candidate='b51aebc7e4735529befd677ebf14071c7f09e477'))
challenge('zero executed rows',lambda e:e.update(raw=[]))
challenge('mismatched corpus identity',lambda e:e.update(corpus_inventory='0'*64))
def abstain(e):
    r=next(r for r in e['reports']['rust']['rows'] if r['case_id']=='spec0231-oracle-helper-assert-json-eq');r.update(observed_verdict='limited',outcome='abstained')
challenge('abstention substituted for repaired credit',abstain)
(out/'integrity.json').write_text(json.dumps(dict(positive_packet_accepted=True,selected=sum(len(v) for v in expected_defs.values()),raw_executed=len(receipts),challenges=challenges,scope='analytical custody audit only; repository admission/population controls are separately executed'),indent=2))
print((out/'integrity.json').read_text())
