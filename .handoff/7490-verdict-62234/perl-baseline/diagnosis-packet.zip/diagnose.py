import pathlib,subprocess,json,hashlib,collections
root=pathlib.Path('/workspace/ripr-swarm'); out=pathlib.Path('/workspace/scratch/verdict-62234')
def digest(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False)
def files(rev,prefix):return subprocess.check_output(['git','ls-tree','-r','--name-only',rev,prefix],cwd=root,text=True).splitlines()
def read(rev,p):return subprocess.check_output(['git','show',rev+':'+p],cwd=root)
def load(rev,p):return json.loads(read(rev,p))
def definitions(rev,lang):
    base=f'fixtures/{lang}-verdict-corpus/'
    corpus=load(rev,base+'corpus.json')
    subjects={s['subject_id']:s for p in files(rev,base+'subjects/') if p.endswith('.json') and len(p[len(base+'subjects/'):].split('/'))==1 for s in [load(rev,p)]}
    cases={c['case_id']:c for p in files(rev,base+'cases/') if p.endswith('.json') for c in [load(rev,p)]}
    result={}
    for cid,c in cases.items():
        s=subjects[c['subject_id']]
        identity=dict(origin=s.get('origin','upstream'),upstream=s.get('upstream'),commit=s.get('commit'),files=sorted([dict(path=f['path'],sha256=f['sha256']) for f in s['retained_files']],key=lambda x:x['path']))
        mutants=sorted([dict(replacement=m['replacement'],outcome=m['outcome']) for m in c['truth']['mutants']],key=canonical)
        definition=dict(schema=corpus['schema_version'],projection=corpus['verdict_projection'],case_id=cid,subject_id=c['subject_id'],anchor=c['anchor'],edit_kind=c['edit_kind'],truth=c['truth']['state'],ideal=c['expected']['ideal_verdict'],acceptable=sorted(c['expected']['acceptable_verdicts'],key=canonical),mutants=mutants,diff_sha256=digest(read(rev,base+c['diff'])),subject=identity)
        if c.get('perl_facts'):definition['perl_facts']=dict(sha256=c['perl_facts']['sha256'],provenance=c['perl_facts']['provenance'],producer=corpus.get('fact_producer'))
        result[cid]=dict(hash=digest(canonical(definition).encode()),definition=definition)
    return result

import argparse
parser=argparse.ArgumentParser(description='Read-only Perl baseline custody and definition comparison; no analyzer, producer, CI or baseline mutation')
parser.add_argument('--repo',default='/workspace/ripr-swarm');parser.add_argument('--current-report',default='/workspace/scratch/verdict-62234/dx-scoreboard.json');parser.add_argument('--out',default='/workspace/scratch/perl-baseline-diagnosis/diagnosis.json')
args=parser.parse_args();root=pathlib.Path(args.repo)
baseline_path=root/'metrics/dx-scoreboard/baseline.json';base=json.loads(baseline_path.read_text());native=json.loads(pathlib.Path(args.current_report).read_text());current=definitions('HEAD','perl');historical={};results=[]
for oldrow in base['metrics']:
    if not oldrow['id'].startswith('trust.perl_verdict_corpus_'):continue
    row=next(r for r in native['metrics'] if r['id']==oldrow['id']);sample=oldrow['samples'][0];provenance=sample['population_provenance'];rev=provenance['revision']
    if rev not in historical:historical[rev]=definitions(rev,'perl')
    olddefs=historical[rev];bp=sample['population'];cp=row['samples'][0]['population'];old={x['case_id']:x for x in bp['cases']};now={x['case_id']:x for x in cp['cases']};shared=set(old)&set(now)
    assert all(old[x]['definition_sha256']==olddefs[x]['hash'] for x in old)
    assert all(now[x]['definition_sha256']==current[x]['hash'] for x in now)
    assert subprocess.check_output(['git','rev-parse',rev+':fixtures/perl-verdict-corpus/corpus.json'],cwd=root,text=True).strip()==provenance['corpus_blob']
    assert subprocess.check_output(['git','rev-parse',rev+':fixtures/perl-verdict-corpus/expected/rows'],cwd=root,text=True).strip()==provenance['rows_tree']
    def pair(xs):return [sum(x['numerator'] for x in xs),sum(x['denominator'] for x in xs)]
    eligible=[x for x in shared if old[x]['definition_sha256']==now[x]['definition_sha256']]
    assert not eligible
    results.append(dict(metric=row['id'],baseline_provenance=provenance,baseline_cases=len(old),current_cases=len(now),shared_case_ids=len(shared),unchanged_definitions=len(eligible),changed_definitions=sorted(shared-set(eligible)),added=sorted(set(now)-set(old)),removed=sorted(set(old)-set(now)),eligibility_changes=[x for x in shared if old[x]['denominator']!=now[x]['denominator']],baseline_fraction=pair(old.values()),current_retained_id_fraction_NOT_definition_comparable=pair(now[x] for x in shared),added_fraction=pair(now[x] for x in set(now)-set(old)),current_full_fraction=pair(now.values()),native_comparison=row['baseline']))
packet_checks={}
for rev,defs in historical.items():
    cases=[]
    for cid in defs:
        path='fixtures/perl-verdict-corpus/cases/'+cid+'.json';a=load(rev,path);b=load('HEAD',path)
        oldbytes=read(rev,'fixtures/perl-verdict-corpus/'+a['perl_facts']['packet']);newbytes=read('HEAD','fixtures/perl-verdict-corpus/'+b['perl_facts']['packet'])
        assert digest(oldbytes)==a['perl_facts']['sha256'] and digest(newbytes)==b['perl_facts']['sha256']
        oldpacket=json.loads(oldbytes);newpacket=json.loads(newbytes);changed=sorted(k for k in set(oldpacket)|set(newpacket) if oldpacket.get(k)!=newpacket.get(k))
        cases.append(dict(case_id=cid,definition_changed_fields=sorted(k for k in defs[cid]['definition'] if defs[cid]['definition'][k]!=current[cid]['definition'][k]),packet_changed_fields=changed,producer_only_packet_change=changed==['producer']))
    packet_checks[rev]=dict(verified_packets=len(cases),producer_only_changes=sum(c['producer_only_packet_change'] for c in cases),cases=cases)
report=dict(subject=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=root,text=True).strip(),baseline_sha256=digest(baseline_path.read_bytes()),baseline_top_level_revision_NOT_perl_source=base['revision'],current_native_report_sha256=digest(pathlib.Path(args.current_report).read_bytes()),comparisons=results,packet_custody=packet_checks,conclusion='Correct fail-closed incomparability after verified producer/packet migration; no scorer/custody repair indicated. Same-ID fractions are descriptive only. Baseline re-admission and abstention acceptance/rejection remain existing owner decisions.')
pathlib.Path(args.out).write_text(json.dumps(report,indent=2));print(json.dumps(dict(subject=report['subject'],comparisons=[{k:r[k] for k in ['metric','baseline_cases','current_cases','shared_case_ids','unchanged_definitions','eligibility_changes','baseline_fraction','current_retained_id_fraction_NOT_definition_comparable','added_fraction','current_full_fraction']} for r in results],packet_custody={rev:{k:v for k,v in d.items() if k!='cases'} for rev,d in packet_checks.items()}),indent=2))
